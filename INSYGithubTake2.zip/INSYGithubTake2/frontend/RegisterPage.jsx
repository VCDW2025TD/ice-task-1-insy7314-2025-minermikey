import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api"; // Axios instance for backend communication
import "./Register.css"; // Make sure to create and style this file

const Register = () => {
  // Local state for form inputs and error handling
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const navigate = useNavigate();

  // Handle form submission
  const handleRegister = async (e) => {
    e.preventDefault(); // Prevent default form reload
    setError(""); // Clear any previous errors

    try {
      // Send registration data to backend
      const response = await API.post("/auth/register", { email, password });

      // Store JWT token from backend response
      localStorage.setItem("token", response.data.token);

      // Redirect to dashboard
      navigate("/dashboard");
    } catch (err) {
      console.error("Registration error:", err);
      setError(
        err.response?.data?.message || "Registration failed. Please try again."
      );
    }
  };

  return (
    <div className="register-container">
      <h2 className="register-heading">Register</h2>

      {/* Show error if exists */}
      {error && <p className="error-message">{error}</p>}

      <form onSubmit={handleRegister} className="register-form">
        {/* Email Field */}
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        {/* Password Field */}
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        {/* Submit Button */}
        <button type="submit" className="register-btn">
          Register
        </button>
      </form>
    </div>
  );
};

export default Register;
