// frontend/src/utils/validators.js

// pretty sure this tests the email validation 
export const isValidEmail = (email) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || "").trim());

// this will ensure that the password is strong and   
  export const isStrongPassword = (password) =>
    /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?-]{8,}$/.test(String(password || ""));