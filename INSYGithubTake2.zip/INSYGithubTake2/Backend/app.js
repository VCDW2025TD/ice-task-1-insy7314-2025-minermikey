// // Import the Express framework to build the web server
// const express = require('express');

// // Import CORS middleware to allow cross-origin requests (e.g., React frontend calling Express backend)
// const cors = require('cors');

// // Import Helmet to set various secure HTTP headers automatically
// const helmet = require('helmet');

// // Import dotenv to load environment variables from a .env file into process.env
// const dotenv = require('dotenv');

// // Load environment variables (e.g., PORT, DB URI)
// dotenv.config();

// // Create an instance of an Express application
// const app = express();

// // Apply Helmet middleware to secure the app by setting HTTP headers (e.g., XSS, frameguard, HSTS)
// app.use(helmet());

// // Enable CORS so that requests from other origins (like the frontend) are allowed
// app.use(cors());

// // Enable Express to parse incoming JSON payloads (used in POST and PUT requests)
// app.use(express.json());

// // Define a simple route at the root URL to confirm the server is running
// app.get('/', (req, res) => {
//   res.send('Secure Blog API running!');
// });

// app.get('/test', (req, res) => {
//     res.json({ message: 'This is Secure Blog JSON response' });
//   });

// // Export the app so it can be used in server.js
// module.exports = app;

// const express = require("express");
// const cors = require("cors");
// const helmet = require("helmet");
// const dotenv = require("dotenv");

// dotenv.config();

// const app = express();

// // Security middlewares
// app.use(helmet());
// app.use(cors({
//   origin: "https://localhost:5173",
//   credentials: true
// }));
// app.use(express.json()); // Parse JSON bodies

// // this is for using helmet 

// // ( Make changes to your front-end application to trigger violations of this policy. )
// app.use(
//   helmet.contentSecurityPolicy({
//       directives: {
//       defaultSrc: ["'self'"],
//       scriptSrc: ["'self'", "https://apis.google.com"],
//       styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
//       fontSrc: ["'self'", "https://fonts.gstatic.com"],
//       imgSrc: ["'self'", "data:"],
//       connectSrc: ["'self'", "http://localhost:5001"], // or whichever port you use
//       },
//   })
//   );

// // Routes
// const authRoutes = require("./routes/authRoutes.js");
// const { protect } = require("./middleware/authMiddleware");

// app.use("/api/auth", authRoutes);

// // Example protected route
// app.get("/api/protected", protect, (req, res) => {
//   res.json({
//     message: `Welcome, user ${req.user.id}!`,
//     timestamp: new Date()
//   });
// });

// module.exports = app;



// server.js
const express = require("express");
const helmet = require("helmet");

const app = express();

// Parse JSON and CSP reports sent by the browser.
// WHY: Browsers POST CSP violation reports with content-type application/csp-report.
// We also accept application/json for convenience across browsers.
app.use(express.json({ type: ["application/json", "application/csp-report"] }));

// 1) Baseline security headers (X-Content-Type-Options, Referrer-Policy, etc.)
app.use(helmet());

// 2) Content Security Policy
// WHY: Start with strict defaults. Only our own origin ('self') can provide scripts, styles, images,
// and network requests. This blocks inline/eval scripts and all 3rd-party resources by default.
const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'"],   // no inline scripts, no eval, no external CDNs
  styleSrc: ["'self'"],    // no inline styles, no external styles
  imgSrc: ["'self'"],      // images must come from our origin
  connectSrc: ["'self'"],  // fetch/XHR/WebSocket to our origin only
  frameAncestors: ["'none'"], // cannot embed this site in iframes (prevents clickjacking)
  upgradeInsecureRequests: [] // if serving over https, upgrade http->https automatically
};

app.use(
  helmet.contentSecurityPolicy({
    useDefaults: true,       // keep Helmet’s sane defaults (e.g., base-uri 'self')
    directives: {
      ...cspDirectives,
      // WHY: Tell the browser where to POST violation reports so we can review them during the lab.
      "report-uri": ["/csp-report"],
    },
    // WHY: In dev we want to SEE violations without breaking the app.
    // In production we will enforce (block) instead.
    reportOnly: process.env.NODE_ENV !== "production",
  })
);

// 3) Receive browser violation reports
// WHY: Gives us concrete, inspectable evidence of blocked actions.
app.post("/csp-report", (req, res) => {
  console.log("CSP Violation Report:", JSON.stringify(req.body, null, 2));
  res.sendStatus(204);
});

// Example health route
app.get("/api/health", (_req, res) => {
  res.json({ ok: true, ts: new Date().toISOString() });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`SecureBlog API running at http://localhost:${PORT}`);
  console.log(
    `CSP mode: ${process.env.NODE_ENV !== "production" ? "REPORT-ONLY (dev)" : "ENFORCED (prod)"}`
  );
});